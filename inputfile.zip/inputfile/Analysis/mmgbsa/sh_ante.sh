ante-MMPBSA.py -p ../01_jak1_sosc1_1.parm7 -s ":287-294,455-100000000000000000" -c complex.parm7
ante-MMPBSA.py -p complex.parm7 -n ":287-10000000000000000" -l ligand.parm7 -r receptor.parm7
