MMPBSA.py -O -i mmpbsa.in -o y49pho_complex_1_final.dat -do y49pho_complex_1_decomp.dat -cp ../complex.parm7 -rp ../receptor.parm7 -lp ../ligand.parm7 -y ../y49pho_complex_1.dcd &
